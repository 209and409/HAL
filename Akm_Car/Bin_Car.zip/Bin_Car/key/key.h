#ifndef  __KEY_H
#define  __KEY_H

#include "sys.h"
u8 click(void);
void Delay_ms(void);
u8 click_N_Double_MPU6050 (u8 time);


#endif
