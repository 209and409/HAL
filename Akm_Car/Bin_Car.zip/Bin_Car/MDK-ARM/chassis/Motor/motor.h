#ifndef  __motor_H
#define  __motor_H

#include "main.h"
#include "tim.h"

#define PI 3.14159265
#define T 0.156f
#define L 0.1445f
#define K 622.8f
#define servo_init 1500
#define AIN1_SET HAL_GPIO_WritePin(AIN1_GPIO_Port,AIN1_Pin,GPIO_PIN_SET);
#define AIN1_RESET HAL_GPIO_WritePin(AIN1_GPIO_Port,AIN1_Pin,GPIO_PIN_RESET);
#define BIN1_SET HAL_GPIO_WritePin(BIN1_GPIO_Port,BIN1_Pin,GPIO_PIN_SET);
#define BIN1_RESET HAL_GPIO_WritePin(BIN1_GPIO_Port,BIN1_Pin,GPIO_PIN_RESET);

void motor_set(int motor1,int motor2);
//������С��
void forward(void);
void back(void);
void right(void);
void left(void);
void stop(void);
void turn_90(void);
void turn_back(void);
//������С��
void forward_ref(void);
void back_ref(void);
void right_ref(void);
void left_ref(void);
void stop_ref(void);
void turnright_90_ref(void);
void turnleft_90_ref(void);
void motorpidsetspeed(float motor1setspeed,float motor2setspeed);
void AKMcar(float motor1setspeed,float motor2setspeed,float motorsetspeed,float angle);
#endif
