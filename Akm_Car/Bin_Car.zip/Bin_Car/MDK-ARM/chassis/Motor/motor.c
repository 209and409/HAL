#include "motor.h"
#include "usart.h"
#include "main.h"
#include "tim.h"
#include "gpio.h"
#include "pid.h"
#include "freertos.h"
#include "math.h"

//#define MAX_SPEED_UP  10
//#define MAX_SPEED_Cut 0.5

extern Pid pidMotor1Speed;
extern Pid pidMotor2Speed;
extern float Motor1Speed;
extern float Motor2Speed;
float motor1setspeed=0.00;
float motor2setspeed=0.00;
extern float Pitch,Roll,Yaw;   //ŷ����
float servo=0.00;

void motor_set(int motor1,int motor2)
{
	motor1=-motor1;
	motor2=-motor2;
	if(motor1 < 0) {AIN1_SET;}
		else  {AIN1_RESET;}
	if(motor2 < 0) {BIN1_SET;}
		else  {BIN1_RESET;}
		
	if(motor1<0)
	{
		if(motor1 < -99) motor1=-99;
		__HAL_TIM_SET_COMPARE(&htim9,TIM_CHANNEL_1,100+motor1);
	}
	else
	{
		if(motor1>99) motor1=99 ;
		__HAL_TIM_SET_COMPARE(&htim9,TIM_CHANNEL_1,motor1);
	}	
		if(motor2<0)
	{
		if(motor2<-99) motor2=-99	;
		__HAL_TIM_SET_COMPARE(&htim10,TIM_CHANNEL_1,100+motor2);
	}
	else
	{
		if(motor2>99) motor2=99 ;
		__HAL_TIM_SET_COMPARE(&htim10,TIM_CHANNEL_1,motor2);
	}	
}

//void motorPidSpeedUp(void)//����
//{
//	static float motorSpeedUp = 0.1;
//	if(motorSpeedUp < MAX_SPEED_UP) motorSpeedUp +=0.1;
//	motorPidSetSpeed(motorSpeedUp,motorSpeedUp);
//}
//void motorPidSpeedCut(void)//����
//{
//	static float motorSpeedCut = 8;
//	if(motorSpeedCut > MAX_SPEED_Cut) motorSpeedCut -=0.5;
//	motorPidSetSpeed(motorSpeedCut,motorSpeedCut);
//}

void forward(void)
{
	motorpidsetspeed(-2,-2);//��ǰ
}
void forward_ref(void)
{
	AKMcar(2,2,0,0);
}
void back(void)
{
	motorpidsetspeed(2,2);//���
}
void back_ref(void)
{
	AKMcar(-2,-2,0,0);
}
void right(void)
{
	motorpidsetspeed(2,0);//�ұ�
}
void right_ref(void)
{
	AKMcar(0,0,2,PI/5);
}
void left(void)
{
	motorpidsetspeed(0,2);//���
}
void left_ref(void)
{
	AKMcar(0,0,2,-PI/5);
}
void stop(void)
{
	motorpidsetspeed(0,0);//ֹͣ
}
void stop_ref(void)
{
	AKMcar(0,0,0,0);
}
void turn_90(void)
{
		//motorpidsetspeed(-1,1);
	
	 if(Vertical_turn(Yaw)<0)
	 {
		motorpidsetspeed(-0.01*(85-Yaw),0.01*(85-Yaw));
		while(Vertical_turn(Yaw)==0)
		stop();
	 }
	else if(Vertical_turn(Yaw)>0)
	{
		motorpidsetspeed(0.01*(85-Yaw),-0.01*(85-Yaw));
		while(Vertical_turn(Yaw)==0)
		stop();
	 }
}
void turnright_90_ref(void)
{
	AKMcar(0,0,2,PI/2);
}
void turnleft_90_ref(void)
{
	AKMcar(0,0,2,-PI/2);
}
void turn_back(void)
{
		//motorpidsetspeed(-1,1);
	 if(Vertical_turn(Yaw)<90)
	 {
		motorpidsetspeed(0.01*(Yaw),-0.01*(Yaw));
		while(Vertical_turn(Yaw)==90)
		stop();
	 }
	else if(Vertical_turn(Yaw)>90)
	{
		motorpidsetspeed(-0.01*(Yaw),0.01*(Yaw));
		while(Vertical_turn(Yaw)==90)
		stop();
	 }
}
void motorpidsetspeed(float motor1setspeed,float motor2setspeed)
{
	pidMotor1Speed.target_val = motor1setspeed;
	pidMotor2Speed.target_val = motor2setspeed;
  motor_set(PID_realize(&pidMotor1Speed,Motor1Speed),PID_realize(&pidMotor2Speed,Motor2Speed));
}
void AKMcar(float motor1setspeed,float motor2setspeed,float motorsetspeed,float angle)
{
	motor1setspeed=motorsetspeed*(1+T*tan(angle)/2/L);
	motor2setspeed=motorsetspeed*(1+T*tan(angle)/2/L);
	servo=servo_init+angle*K;
	pidMotor1Speed.target_val = motor1setspeed;
	pidMotor2Speed.target_val = motor2setspeed;
	motor_set(PID_realize(&pidMotor1Speed,Motor1Speed),PID_realize(&pidMotor2Speed,Motor2Speed));
	__HAL_TIM_SET_COMPARE(&htim12,TIM_CHANNEL_1,servo);
}

