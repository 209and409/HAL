/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * File Name          : freertos.c
  * Description        : Code for freertos applications
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2023 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "FreeRTOS.h"
#include "task.h"
#include "main.h"
#include "cmsis_os.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "usartx.h"
#include "motor.h"
#include "mpu6050.h"
#include "sys.h"
#include "PidControl.h"
#include "tim.h"
#include "stdio.h"
#include "show.h"
#include "string.h"
#include "oled.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
/* USER CODE BEGIN Variables */





/* USER CODE END Variables */
osThreadId BalanceHandle;
osThreadId MPU6050Handle;
osThreadId showHandle;
osThreadId ledHandle;
osThreadId dataHandle;
osThreadId BluetoothHandle;

/* Private function prototypes -----------------------------------------------*/
/* USER CODE BEGIN FunctionPrototypes */

/* USER CODE END FunctionPrototypes */

void Balance_task(void const * argument);
void MPU_task(void const * argument);
void show_task(void const * argument);
void led_task(void const * argument);
void data_task(void const * argument);
void Bluetooth_task(void const * argument);

void MX_FREERTOS_Init(void); /* (MISRA C 2004 rule 8.1) */

/* GetIdleTaskMemory prototype (linked to static allocation support) */
void vApplicationGetIdleTaskMemory( StaticTask_t **ppxIdleTaskTCBBuffer, StackType_t **ppxIdleTaskStackBuffer, uint32_t *pulIdleTaskStackSize );

/* USER CODE BEGIN GET_IDLE_TASK_MEMORY */
static StaticTask_t xIdleTaskTCBBuffer;
static StackType_t xIdleStack[configMINIMAL_STACK_SIZE];

void vApplicationGetIdleTaskMemory( StaticTask_t **ppxIdleTaskTCBBuffer, StackType_t **ppxIdleTaskStackBuffer, uint32_t *pulIdleTaskStackSize )
{
  *ppxIdleTaskTCBBuffer = &xIdleTaskTCBBuffer;
  *ppxIdleTaskStackBuffer = &xIdleStack[0];
  *pulIdleTaskStackSize = configMINIMAL_STACK_SIZE;
  /* place for user code */
}
/* USER CODE END GET_IDLE_TASK_MEMORY */

/**
  * @brief  FreeRTOS initialization
  * @param  None
  * @retval None
  */
void MX_FREERTOS_Init(void) {
  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* USER CODE BEGIN RTOS_MUTEX */
  /* add mutexes, ... */
  /* USER CODE END RTOS_MUTEX */

  /* USER CODE BEGIN RTOS_SEMAPHORES */
  /* add semaphores, ... */
  /* USER CODE END RTOS_SEMAPHORES */

  /* USER CODE BEGIN RTOS_TIMERS */
  /* start timers, add new ones, ... */
  /* USER CODE END RTOS_TIMERS */

  /* USER CODE BEGIN RTOS_QUEUES */
  /* add queues, ... */
  /* USER CODE END RTOS_QUEUES */

  /* Create the thread(s) */
  /* definition and creation of Balance */
  osThreadDef(Balance, Balance_task, osPriorityNormal, 0, 512);
  BalanceHandle = osThreadCreate(osThread(Balance), NULL);

  /* definition and creation of MPU6050 */
  osThreadDef(MPU6050, MPU_task, osPriorityBelowNormal, 0, 256);
  MPU6050Handle = osThreadCreate(osThread(MPU6050), NULL);

  /* definition and creation of show */
  osThreadDef(show, show_task, osPriorityBelowNormal, 0, 512);
  showHandle = osThreadCreate(osThread(show), NULL);

  /* definition and creation of led */
  osThreadDef(led, led_task, osPriorityBelowNormal, 0, 128);
  ledHandle = osThreadCreate(osThread(led), NULL);

  /* definition and creation of data */
  osThreadDef(data, data_task, osPriorityNormal, 0, 512);
  dataHandle = osThreadCreate(osThread(data), NULL);

  /* definition and creation of Bluetooth */
  osThreadDef(Bluetooth, Bluetooth_task, osPriorityNormal, 0, 128);
  BluetoothHandle = osThreadCreate(osThread(Bluetooth), NULL);

  /* USER CODE BEGIN RTOS_THREADS */
  /* add threads, ... */
  /* USER CODE END RTOS_THREADS */

}

/* USER CODE BEGIN Header_Balance_task */
/**
  * @brief  Function implementing the Balance thread.
  * @param  argument: Not used
  * @retval None
  */
/* USER CODE END Header_Balance_task */
void Balance_task(void const * argument)
{
  /* USER CODE BEGIN Balance_task */
	TickType_t xlastWakeTime;
	xlastWakeTime = xTaskGetTickCount();
  /* Infinite loop */
  for(;;)
  {
		vTaskDelayUntil(&xlastWakeTime, 10);
    balance_task();
  }
  /* USER CODE END Balance_task */
}

/* USER CODE BEGIN Header_MPU_task */
/**
* @brief Function implementing the MPU6050 thread.
* @param argument: Not used
* @retval None
*/
/* USER CODE END Header_MPU_task */
void MPU_task(void const * argument)
{
  /* USER CODE BEGIN MPU_task */
  /* Infinite loop */
 
//	TickType_t xlastWakeTime;
//	xlastWakeTime = xTaskGetTickCount();
  /* Infinite loop */
  for(;;)
  {
		//vTaskDelayUntil(&xlastWakeTime, 10);
		mpu6050_task();		
  }
	
  /* USER CODE END MPU_task */
}

/* USER CODE BEGIN Header_show_task */
/**
* @brief Function implementing the show thread.
* @param argument: Not used
* @retval None
*/
/* USER CODE END Header_show_task */
void show_task(void const * argument)
{
  /* USER CODE BEGIN show_task */
	TickType_t xlastWakeTime;
	xlastWakeTime = xTaskGetTickCount();
  /* Infinite loop */
  for(;;)
  {
		vTaskDelayUntil(&xlastWakeTime, 10);
		oled_task();
  }
  /* USER CODE END show_task */
}

/* USER CODE BEGIN Header_led_task */
/**
* @brief Function implementing the led thread.
* @param argument: Not used
* @retval None
*/
/* USER CODE END Header_led_task */
void led_task(void const * argument)
{
  /* USER CODE BEGIN led_task */
  /* Infinite loop */
  for(;;)
  {
    HAL_GPIO_WritePin(LED_GPIO_Port,LED_Pin,1);
		osDelay(500);
		HAL_GPIO_WritePin(LED_GPIO_Port,LED_Pin,0);
		osDelay(500);
  }
  /* USER CODE END led_task */
}

/* USER CODE BEGIN Header_data_task */
/**
* @brief Function implementing the data thread.
* @param argument: Not used
* @retval None
*/
/* USER CODE END Header_data_task */
void data_task(void const * argument)
{
  /* USER CODE BEGIN data_task */
  /* Infinite loop */
	TickType_t xLastWakeTime;
	xLastWakeTime = xTaskGetTickCount();
  for(;;)
  {
	//Assign the data to be sent
	//��Ҫ���з��͵����ݽ��и�ֵ
	  data_transition(); 
	  USART3_SEND();     //Serial port 1 sends data //����1��������
	   //The task is run at 20hz
	//��������20Hz��Ƶ������
	  vTaskDelayUntil(&xLastWakeTime,50);		
  }
  /* USER CODE END data_task */
}

/* USER CODE BEGIN Header_Bluetooth_task */
/**
* @brief Function implementing the Bluetooth thread.
* @param argument: Not used
* @retval None
*/
/* USER CODE END Header_Bluetooth_task */
void Bluetooth_task(void const * argument)
{
  /* USER CODE BEGIN Bluetooth_task */
//	TickType_t xLastWakeTime;
//	xLastWakeTime = xTaskGetTickCount();
//  /* Infinite loop */
//  for(;;)
//  {
////		Get_RC();
//		vTaskDelayUntil(&xLastWakeTime,10);	
//  }
  /* USER CODE END Bluetooth_task */
}

/* Private application code --------------------------------------------------*/
/* USER CODE BEGIN Application */

/* USER CODE END Application */
