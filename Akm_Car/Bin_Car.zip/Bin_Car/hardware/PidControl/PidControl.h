#ifndef __PIDCONTROL_H
#define __PIDCONTROL_H
#include "sys.h"

void Drive_Motor(float Vx,float Vy,float Vz);
u8 Turn_Off( int voltage);
int Incremental_PI_A (float Encoder,float Target);
int Incremental_PI_B (float Encoder,float Target);
void Get_RC(void);
void Key(void);
//void Smooth_control(float vx,float vy,float vz);
float float_abs(float insert);
void balance_task(void);
#endif

