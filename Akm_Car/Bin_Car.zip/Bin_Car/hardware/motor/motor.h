#ifndef  __motor_H
#define  __motor_H
void Set_Pwm(int motor_a,int motor_b,int servo);
void Limit_Pwm(int amplitude);
float target_limit_float(float insert,float low,float high);
int target_limit_int(int insert,int low,int high);
void PWM_SetCompare(double Compare1,double Compare2);
void Servo1_SetAngle(double Angle1,double Angle2);
#define SERVO_INIT 1500  //Servo zero point //������

#endif
