#ifndef  __USARTX_H
#define  __USARTX_H

#include "stdio.h"
#include "main.h"
#include "usartx.h"
#include "usart.h"

#define FRAME_HEADER      9 //Frame_header //֡ͷ
#define SEND_DATA_SIZE    24
/*******���ڷ������ݵĽṹ��*************************************/
typedef struct _SEND_DATA_  
{
	char key_flag;
}SEND_DATA;

extern 	float motor1targetspeed;
extern	float motor2targetspeed;
float XY_Target_Speed_transition(uint8_t High,uint8_t Low);

void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart);
void data_transition(void);
void USART3_SEND(void);
void usart3_send(uint8_t data);	
#endif
