#ifndef __MOTOR_H__
#define __MOTOR_H__

#include "main.h"

#define AIN1_SET  HAL_GPIO_WritePin(GPIOF,Motor1_INA_Pin,GPIO_PIN_SET)
#define AIN1_RESET  HAL_GPIO_WritePin(GPIOF,Motor1_INA_Pin,GPIO_PIN_RESET)
#define AIN2_SET  HAL_GPIO_WritePin(GPIOF,Motor1_INB_Pin,GPIO_PIN_SET)
#define AIN2_RESET  HAL_GPIO_WritePin(GPIOF,Motor1_INB_Pin,GPIO_PIN_RESET)

#define BIN1_SET  HAL_GPIO_WritePin(GPIOF,Motor2_INA_Pin,GPIO_PIN_SET)
#define BIN1_RESET  HAL_GPIO_WritePin(GPIOF,Motor2_INA_Pin,GPIO_PIN_RESET)
#define BIN2_SET  HAL_GPIO_WritePin(GPIOF,Motor2_INB_Pin,GPIO_PIN_SET)
#define BIN2_RESET  HAL_GPIO_WritePin(GPIOF,Motor2_INB_Pin,GPIO_PIN_RESET)

void motor_set(int motor1,int motor2);
void forward(void);
void back(void);
void right(void);
void left(void);
void stop(void);
void motorpidsetspeed(float motor1setspeed,float motor2setspeed);
void	turn_90_R(void);
void	turn_90_L(void);
#endif
