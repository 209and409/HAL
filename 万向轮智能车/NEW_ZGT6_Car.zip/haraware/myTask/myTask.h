#ifndef __MYTASK_H__
#define __MYTASK_H__

void	Oled_Task(void);
void	Led_Task(void);
void	Jdy_Task(void);
void	Key_Task(void);
void	Run_Task(void);

#endif

