#include "motor.h"
#include "tim.h"
#include "pid.h"

extern Pid pidMotor1Speed;
extern Pid pidMotor2Speed;
extern float Motor1Speed;
extern float Motor2Speed;
extern float Pitch,Roll,Yaw;   //ŷ����

void motor_set(int motor1,int motor2)
{
	  if(motor1<0)  //��ת
		{
			AIN1_RESET;
			AIN2_SET;
			__HAL_TIM_SET_COMPARE(&htim1,TIM_CHANNEL_1,-motor1);
		}
		if(motor1>0)  //��ת
		{
			AIN1_SET;
			AIN2_RESET;
			__HAL_TIM_SET_COMPARE(&htim1,TIM_CHANNEL_1,motor1);
		}
		if(motor1==0)  //ֹͣ
		{
			AIN1_RESET;
			AIN2_RESET;
			__HAL_TIM_SET_COMPARE(&htim1,TIM_CHANNEL_1,motor1);
		}		
		if(motor2<0)   //��ת
		{
			BIN2_SET;
			BIN1_RESET;
			__HAL_TIM_SET_COMPARE(&htim1,TIM_CHANNEL_4,-motor2);
		}
		if(motor2>0)   //��ת
		{
			BIN1_SET;
			BIN2_RESET;
			__HAL_TIM_SET_COMPARE(&htim1,TIM_CHANNEL_4,motor2);
		}
		if(motor2==0)  //ֹͣ
		{
			BIN1_RESET;
			BIN2_RESET;
			__HAL_TIM_SET_COMPARE(&htim1,TIM_CHANNEL_4,motor2);
		}

		
}		


void forward(void)
{
	motorpidsetspeed(-2,-2);//��ǰ
}
void back(void)
{
	motorpidsetspeed(2,2);//���
}
void right(void)
{
	motorpidsetspeed(2,0);//�ұ�
}
void right_ref(void)
{
	motorpidsetspeed(2,0);//��ת��
}
void left(void)
{
	motorpidsetspeed(0,2);//���
}
void left_ref(void)
{
	motorpidsetspeed(0,2);//��ת��
}
void stop(void)
{
	motorpidsetspeed(0,0);//ֹͣ
}
void turn_90(void)
{
		//motorpidsetspeed(-1,1);
	
			 if(Vertical_turn(Yaw)<0)
			 {
				motorpidsetspeed(-0.01*(85-Yaw),0.01*(85-Yaw));
				while(Vertical_turn(Yaw)==0)
				stop();
			 }
			else if(Vertical_turn(Yaw)>0)
			{
				motorpidsetspeed(0.01*(85-Yaw),-0.01*(85-Yaw));
				while(Vertical_turn(Yaw)==0)
				stop();
			 }
}

void turn_back(void)
{
		//motorpidsetspeed(-1,1);
	
			 if(Vertical_turn(Yaw)<90)
			 {
				motorpidsetspeed(0.01*(Yaw),-0.01*(Yaw));
				while(Vertical_turn(Yaw)==90)
				stop();
			 }
			else if(Vertical_turn(Yaw)>90)
			{
				motorpidsetspeed(-0.01*(Yaw),0.01*(Yaw));
				while(Vertical_turn(Yaw)==90)
				stop();
			 }
}

void motorpidsetspeed(float motor1setspeed,float motor2setspeed)
{
	pidMotor1Speed.target_val = motor1setspeed;
	pidMotor2Speed.target_val = motor2setspeed;
  motor_set(PID_realize(&pidMotor1Speed,Motor1Speed),PID_realize(&pidMotor2Speed,Motor2Speed));
}


